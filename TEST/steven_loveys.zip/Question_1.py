from Question_1_Classes import Rectangle

rect1 = Rectangle(5, 5)
rect2 = Rectangle(6, 8)
rect3 = Rectangle(-4, 4)

print(rect1.area)
print(rect1.perimeter)
print(rect1.is_square)
print()
print(rect2.area)
print(rect2.perimeter)
print(rect2.is_square)
print()
print(rect3.area)
print(rect3.perimeter)
print(rect3.is_square)
